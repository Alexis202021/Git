package starter.search;

import org.openqa.selenium.By;

class SearchResultList {
    static By RESULT_TITLES = By.cssSelector("#links .result__title");
}
