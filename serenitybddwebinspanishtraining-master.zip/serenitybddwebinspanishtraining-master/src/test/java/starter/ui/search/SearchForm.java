package starter.ui.search;

import org.openqa.selenium.By;

public class SearchForm {
    public static By SEARCH_FIELD = By.id("search_form_input");
    public static By SEARCH_BUTTON = By.id("search_button");
}
