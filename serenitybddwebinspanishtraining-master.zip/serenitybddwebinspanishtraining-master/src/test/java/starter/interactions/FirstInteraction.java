package starter.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;

public class FirstInteraction implements Interaction {
    @Override
    public <T extends Actor> void performAs(T t) {

    }
}
