package starter.conf;

public enum SessionVariables {
    FOO
}
